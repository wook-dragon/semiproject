package kr.or.bit.service;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.or.bit.action.Action;
import kr.or.bit.action.ActionForward;
import kr.or.bit.dao.Admindao;
import kr.or.bit.dao.empdao;
import kr.or.bit.dto.adminlist;
import kr.or.bit.dto.emp;
import net.sf.json.JSONObject;

public class LoginOkService implements Action {

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {
      ActionForward forward = new ActionForward();
      HttpSession session = request.getSession();
      String id = request.getParameter("userid");
      String pwd = request.getParameter("pwd");
      
      
      System.out.println("클라이언트가 입력한 아이디 값 " + ">"+id+"<");
      System.out.println("클라이언트가 입력한 비번 " + ">"+pwd+"<");
      System.out.println(pwd instanceof String); 
       
        Admindao dao = new Admindao();
        adminlist adminlist = new adminlist();
        
        adminlist = dao.loginCheck(id);
        
      
        if(adminlist.getUserid().equals(id)) {
            if(adminlist.getPwd().equals(pwd)) {
               session.setAttribute("userid", id);
               forward.setPath("/gomain.do");
            }else {
               System.out.println("틀린비번");
               forward.setPath("/login.do");
            }
         }else {
            System.out.println("없는아이디");
            forward.setPath("/login.do");
         } 
        System.out.println("다음으로 갈 장소" + forward.getPath());
            return forward;
}

}