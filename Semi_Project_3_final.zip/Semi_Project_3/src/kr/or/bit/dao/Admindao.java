package kr.or.bit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import kr.or.bit.dto.adminlist;
import kr.or.bit.dto.emp;
import kr.or.bit.utils.ConnectionHelper;

public class Admindao {
    public adminlist loginCheck(String id) {
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    adminlist adminlist = new adminlist();

    try {
       conn = ConnectionHelper.getConnection("oracle");
       String sql="select userid, pwd from adminlist where userid=?";
       
       pstmt = conn.prepareStatement(sql);
       pstmt.setString(1, id);
       
       rs = pstmt.executeQuery();
       
       while(rs.next()) {

        adminlist.setUserid(rs.getString("userid"));
        adminlist.setPwd(Integer.toString(rs.getInt("pwd")));
        
          
       }
       System.out.println("데이터나오니 : " + adminlist);
    } catch (Exception e) {

       e.printStackTrace();
       
    }finally {
       
       try {
          rs.close();
          pstmt.close();
          conn.close();  
          
       } catch (SQLException e) {
          e.printStackTrace();
       }

    }
    
    return adminlist;

 }

}