package kr.or.bit.dto;

public class File extends Board { //파일게시판
	private int fidx; //자료실식별번호
	private int oriname;
	private int savename;
	private int size;
	@Override
	public String toString() {
		return "File [fidx=" + fidx + ", oriname=" + oriname + ", savename=" + savename + ", size=" + size + "]";
	}
	
	
	
	
	
	
}
