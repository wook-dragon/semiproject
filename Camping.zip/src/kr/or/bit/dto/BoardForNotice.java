package kr.or.bit.dto;

public class BoardForNotice extends Board {

	
	
	
}
