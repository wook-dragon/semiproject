package kr.or.bit.dto;

public class Zzim_List {	//찜 목록
	public Zzim_List(int camidx, String id) {
		super();
		this.camidx = camidx;
		this.id = id;
	}
	
	
	private int camidx;
	private String id;
	
	
	
	
	@Override
	public String toString() {
		return "Zzim_List [camidx=" + camidx + ", id=" + id + "]";
	}
	
	
	
}
