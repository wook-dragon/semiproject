package kr.or.bit.dto;

public class Member {	//회원
	
	public Member(String id, String pwd, String name, String hp, int grade) {
		super();
		this.id = id;
		this.pwd = pwd;
		this.name = name;
		this.hp = hp;
		this.grade = grade;
	}
	
	
	private String id;
	private String pwd;
	private String name;
	private String hp;
	private int grade;
	@Override
	public String toString() {
		return "Member [id=" + id + ", pwd=" + pwd + ", name=" + name + ", hp=" + hp + ", grade=" + grade + "]";
	}
	
	
	
	
	
}
