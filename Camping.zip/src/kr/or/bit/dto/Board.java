package kr.or.bit.dto;

public class Board {	//게시판
	
	private int idx;
	private String id;
	private int bcode;
	private int tcode;
	private String title;
	private String content;
	private int readnum;
	private String writedate;	//날짜는 String 타입으로
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getBcode() {
		return bcode;
	}
	public void setBcode(int bcode) {
		this.bcode = bcode;
	}
	public int getTcode() {
		return tcode;
	}
	public void setTcode(int tcode) {
		this.tcode = tcode;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getReadnum() {
		return readnum;
	}
	public void setReadnum(int readnum) {
		this.readnum = readnum;
	}
	public String getWritedate() {
		return writedate;
	}
	public void setWritedate(String writedate) {
		this.writedate = writedate;
	}
	
	@Override
	public String toString() {
		return "Board [idx=" + idx + ", id=" + id + ", bcode=" + bcode + ", tcode=" + tcode + ", title=" + title
				+ ", content=" + content + ", readnum=" + readnum + ", writedate=" + writedate + ", getIdx()="
				+ getIdx() + ", getId()=" + getId() + ", getBcode()=" + getBcode() + ", getTcode()=" + getTcode()
				+ ", getTitle()=" + getTitle() + ", getContent()=" + getContent() + ", getReadnum()=" + getReadnum()
				+ ", getWritedate()=" + getWritedate() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

	
	
}
