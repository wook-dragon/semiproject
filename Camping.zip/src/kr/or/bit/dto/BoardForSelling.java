package kr.or.bit.dto;

public class BoardForSelling extends File{ //판매 파일게시판

	public BoardForSelling(int tcode, String tstatus) {
		super();
		this.tcode = tcode;
		this.tstatus = tstatus;
	}
	
	
	
	@Override
	public String toString() {
		return "BoardForSelling [tcode=" + tcode + ", tstatus=" + tstatus + "]";
	}



	private int tcode; //거래코드
	private String tstatus;	//거래상태(데이터타입?)
	
	
}
