package kr.or.bit.dto;

public class BoardForReboard extends Board{	//답글게시판
	
	public BoardForReboard(int reboardidx, int ref, int dept, int step, int reboardcount) {
	super();
	this.reboardidx = reboardidx;
	this.ref = ref;
	this.dept = dept;
	this.step = step;
	this.reboardcount = reboardcount;
}
	
	private int reboardidx;
	private int ref;
	private int dept;
	private int step;
	private int reboardcount;
	@Override
	public String toString() {
		return "BoardForReboard [reboardidx=" + reboardidx + ", ref=" + ref + ", dept=" + dept + ", step=" + step
				+ ", reboardcount=" + reboardcount + "]";
	}
	
	
	
	
	
	
}
