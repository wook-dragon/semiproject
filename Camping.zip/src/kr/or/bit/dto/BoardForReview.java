package kr.or.bit.dto;

public class BoardForReview extends File { //후기게시판
	
	
	
	
	
}
