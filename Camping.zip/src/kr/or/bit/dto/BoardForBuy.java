package kr.or.bit.dto;

public class BoardForBuy extends File {	//구매 파일게시판
	public BoardForBuy(int tcode, String tstatus) {
		super();
		this.tcode = tcode;
		this.tstatus = tstatus;
	}
	
	private int tcode; //거래코드
	private String tstatus;	//거래상태(데이터타입?)
	@Override
	public String toString() {
		return "BoardForBuy [tcode=" + tcode + ", tstatus=" + tstatus + "]";
	}
	
	
}
