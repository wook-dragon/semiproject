package kr.or.bit.dto;

public class Membergrade {	//회원 등급
	public Membergrade(int grade, String gname) {
		super();
		this.grade = grade;
		this.gname = gname;
	}
	
	
	private int grade;
	private String gname;
	@Override
	public String toString() {
		return "Membergrade [grade=" + grade + ", gname=" + gname + "]";
	}
	
	
	
	
	
}
