package kr.or.bit.dto;

public class Campingjang { //캠핑장
	
	public Campingjang(int camdix, String campgnm, String rdnmadr, String officephonenumber, String cvntl,
			String saventl, String etcty, String usetime) {
		super();
		this.camdix = camdix;
		this.campgnm = campgnm;
		this.rdnmadr = rdnmadr;
		this.officephonenumber = officephonenumber;
		this.cvntl = cvntl;
		this.saventl = saventl;
		this.etcty = etcty;
		this.usetime = usetime;
	}
	
	
	
	private int camdix;
	private String campgnm;
	private String rdnmadr;
	private String officephonenumber;
	private String cvntl;
	private String saventl;
	private String etcty;
	private String usetime;
	@Override
	public String toString() {
		return "Campingjang [camdix=" + camdix + ", campgnm=" + campgnm + ", rdnmadr=" + rdnmadr
				+ ", officephonenumber=" + officephonenumber + ", cvntl=" + cvntl + ", saventl=" + saventl + ", etcty="
				+ etcty + ", usetime=" + usetime + "]";
	}
	
	
	
	
	
	
	
	
	
}
