package kr.or.bit.dto;

public class BoardForReply extends Board{	//댓글게시판
	
	
	public BoardForReply(int replyidx, String replycontent, String replyid, String replydate) {
		super();
		this.replyidx = replyidx;
		this.replycontent = replycontent;
		this.replyid = replyid;
		this.replydate = replydate;
	}
	
	
	
	
	
	
	
	@Override
	public String toString() {
		return "BoardForReply [replyidx=" + replyidx + ", replycontent=" + replycontent + ", replyid=" + replyid
				+ ", replydate=" + replydate + "]";
	}







	private int replyidx;
	private String replycontent;
	private String replyid;
	private String replydate;
	
	
}
