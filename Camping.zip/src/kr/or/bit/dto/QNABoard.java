package kr.or.bit.dto;

public class QNABoard extends Board {	//Q&A 계층형게시판

	
	
	
}
