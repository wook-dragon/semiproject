package kr.or.bit.dto;

public class Board_Type {	//게시판 타입

	private int btype_num;
	private String btype_name;
	
	public Board_Type(int btype_num, String btype_name) {
		super();
		this.btype_num = btype_num;
		this.btype_name = btype_name;
	}

	@Override
	public String toString() {
		return "Board_Type [btype_num=" + btype_num + ", btype_name=" + btype_name + "]";
	}
	
	
	
}
